# Estado de entrega - revisión 06-11-2026

Plazo: 20-11-2026, 13:00 h (BDNS 921443, Base 5).

Web: <https://masjovenquetu.eus> (servidor propio, ADR-029). Copia permanente:
<https://huntsman1756.github.io/mas_joven_que_tu-/>. QA de la publicación en
`evidence/vps2-eus-20261106/` y `evidence/pages-20261106/`. Paquete vigente:
`output/pdf/final-20261106/`. Capturas y demo recapturadas el 06-11-2026 desde la web
publicada (build `223b0b5`). Desde la publicación del 01-10-2026
([registro](../../evidence/mobile-map-stability-20261001/RELEASE.md)) no cambian datos ni
métricas. Los registros anteriores son históricos.

## Incorporado de la lista editorial y del benchmark

| Propuesta | Resultado |
| --- | --- |
| Entrada sin formulario | Ver un ejemplo abre f4036; volver repetidamente restaura la portada |
| Cinco conclusiones | Implementadas desde los briefs, sin métricas nuevas |
| Trazabilidad fácil | Método con 60/70, fuente, límites, CSV y diccionario |
| Nombre y subtítulo | Nombre conservado; subtítulo descriptivo en web y tarjeta social |
| Demo de 60-90 s | 76 s, ES, subtítulos, transcripción y versión silenciosa |
| Paquete compacto | Resumen, memoria editable/PDF, fuentes, capturas y manifiesto |
| Lectura móvil | Mapa unos 173 px más cerca en 390 × 844; ejemplos persistentes en campos vacíos |
| Estabilidad del lienzo | Contención CSS y 40 aperturas WebKit en Linux, sin filtrar errores |
| Revisión de copy | ES/EU corregidos y regresiones añadidas; no equivale a revisión nativa |
| Evidencia fotográfica | Smoke decodifica muestras y rechaza imágenes uniformes; captura visual conservada |

Patrones recuperados de las referencias guardadas: ejemplo territorial,
pregunta pública, contraste visual, método accesible y demo de respaldo.
No se copia código ni se añaden modos, backend, 3D o rankings para aparentar
innovación. Nada de ello garantiza un premio. Referencias y límites:
`../remediation/red-team-2026/NEXT_EDITORIAL_DELIVERY.md`.

## Antes de presentar (no simular como terminado)

- Persona o equipo: confirmar elegibilidad, autoría y representación según modelo oficial.
- Completar solicitud y declaraciones por el canal oficial; no guardar DNI ni cuenta bancaria en el repo.
- Adjuntar memoria técnica y fuentes, no confiar únicamente en un enlace al repositorio.
- Comprobar el SHA realmente publicado y actualizar manifiesto/capturas si cambia el candidato.
- Revisión EU por hablante competente; la revisión asistida no acredita naturalidad total.
- Safari iPhone físico, NVDA NV-18/19 y zoom real pendientes. Playwright WebKit no certifica Safari instalado en un iPhone.
- La matriz emula tamaños Android/iPhone/tablet con Chromium, Firefox y WebKit; consultar el resultado del candidato en RELEASE.md.
- Maestro del 30-09-2026 no completó la instrumentación/estabilidad del emulador. La evidencia Android del 28-09-2026 es histórica y no certifica este candidato ni teléfono físico.
- Observar a personas nuevas: qué mide, qué descubren y dónde lo comprueban. Registrar respuestas reales.
- El paquete usa la demo silenciosa subtitulada; la narración sintética histórica queda fuera.
- Verificar requisitos y plazo vigentes en el canal oficial antes de firmar/enviar.

La preparación de archivos no realiza la solicitud ni acepta declaraciones legales.
