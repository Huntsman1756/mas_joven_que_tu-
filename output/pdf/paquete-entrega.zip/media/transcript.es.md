# Transcripción — Más joven que tú

Voz sintética: Microsoft Edge, Elvira (es-ES).

Más joven que tú compara la edad de los edificios de Bizkaia con la tuya. Elige un año y un municipio, o entra directamente en un ejemplo.

En Mungia, casi seis de cada diez edificios actuales con año conocido son posteriores a mil novecientos setenta y nueve. La respuesta muestra el recuento y la cobertura del dato.

En Evolución, el cabezal hace aparecer los edificios según su año registrado. El azul y el rojo los comparan con tu año. Los edificios desaparecidos no están: no reconstruimos el parque histórico.

Las fotografías aéreas permiten comparar el mismo lugar en dos campañas oficiales. La fecha de campaña puede diferir de la del vuelo. Estas imágenes aportan evidencia visual, no nuevas métricas.

El contraste de Mungia: sesenta de setenta edificios son posteriores a mil novecientos setenta y nueve, pero representan solo el uno coma nueve por ciento de la huella en planta del conjunto.

Cómo lo sabemos permite comprobar numerador, denominador y límites, y descargar los cinco casos. Open Data Bizkaia es la fuente principal. Explora la web: la demo solo acompaña a la visualización.
